package org.xtext.example.parser.antlr.internal;

import org.eclipse.xtext.*;
import org.eclipse.xtext.parser.*;
import org.eclipse.xtext.parser.impl.*;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.xtext.parser.antlr.AbstractInternalAntlrParser;
import org.eclipse.xtext.parser.antlr.XtextTokenStream;
import org.eclipse.xtext.parser.antlr.XtextTokenStream.HiddenTokens;
import org.eclipse.xtext.parser.antlr.AntlrDatatypeRuleToken;
import org.xtext.example.services.CNLGrammarAccess;



import org.antlr.runtime.*;
import java.util.Stack;
import java.util.List;
import java.util.ArrayList;

@SuppressWarnings("all")
public class InternalCNLParser extends AbstractInternalAntlrParser {
    public static final String[] tokenNames = new String[] {
        "<invalid>", "<EOR>", "<DOWN>", "<UP>", "RULE_WORD", "RULE_ID", "RULE_INT", "RULE_STRING", "RULE_ML_COMMENT", "RULE_SL_COMMENT", "RULE_WS", "RULE_ANY_OTHER", "'After'", "'{'", "'}'", "'Always'", "'should'", "'remain'", "'valid'", "'until'", "'always'", "'either'", "'or'", "'reaction'", "'is'", "'Reaction'", "'which'", "'must'", "'occur'", "'within'", "'from'", "'immediately'", "'after'", "','"
    };
    public static final int RULE_WORD=4;
    public static final int RULE_STRING=7;
    public static final int RULE_SL_COMMENT=9;
    public static final int T__19=19;
    public static final int T__15=15;
    public static final int T__16=16;
    public static final int T__17=17;
    public static final int T__18=18;
    public static final int T__33=33;
    public static final int T__12=12;
    public static final int T__13=13;
    public static final int T__14=14;
    public static final int EOF=-1;
    public static final int T__30=30;
    public static final int T__31=31;
    public static final int T__32=32;
    public static final int RULE_ID=5;
    public static final int RULE_WS=10;
    public static final int RULE_ANY_OTHER=11;
    public static final int T__26=26;
    public static final int T__27=27;
    public static final int T__28=28;
    public static final int RULE_INT=6;
    public static final int T__29=29;
    public static final int T__22=22;
    public static final int RULE_ML_COMMENT=8;
    public static final int T__23=23;
    public static final int T__24=24;
    public static final int T__25=25;
    public static final int T__20=20;
    public static final int T__21=21;

    // delegates
    // delegators


        public InternalCNLParser(TokenStream input) {
            this(input, new RecognizerSharedState());
        }
        public InternalCNLParser(TokenStream input, RecognizerSharedState state) {
            super(input, state);
             
        }
        

    public String[] getTokenNames() { return InternalCNLParser.tokenNames; }
    public String getGrammarFileName() { return "InternalCNL.g"; }



     	private CNLGrammarAccess grammarAccess;

        public InternalCNLParser(TokenStream input, CNLGrammarAccess grammarAccess) {
            this(input);
            this.grammarAccess = grammarAccess;
            registerRules(grammarAccess.getGrammar());
        }

        @Override
        protected String getFirstRuleName() {
        	return "Model";
       	}

       	@Override
       	protected CNLGrammarAccess getGrammarAccess() {
       		return grammarAccess;
       	}




    // $ANTLR start "entryRuleModel"
    // InternalCNL.g:64:1: entryRuleModel returns [EObject current=null] : iv_ruleModel= ruleModel EOF ;
    public final EObject entryRuleModel() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleModel = null;


        try {
            // InternalCNL.g:64:46: (iv_ruleModel= ruleModel EOF )
            // InternalCNL.g:65:2: iv_ruleModel= ruleModel EOF
            {
             newCompositeNode(grammarAccess.getModelRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleModel=ruleModel();

            state._fsp--;

             current =iv_ruleModel; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleModel"


    // $ANTLR start "ruleModel"
    // InternalCNL.g:71:1: ruleModel returns [EObject current=null] : ( (lv_requirements_0_0= ruleRequirement ) )* ;
    public final EObject ruleModel() throws RecognitionException {
        EObject current = null;

        EObject lv_requirements_0_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:77:2: ( ( (lv_requirements_0_0= ruleRequirement ) )* )
            // InternalCNL.g:78:2: ( (lv_requirements_0_0= ruleRequirement ) )*
            {
            // InternalCNL.g:78:2: ( (lv_requirements_0_0= ruleRequirement ) )*
            loop1:
            do {
                int alt1=2;
                int LA1_0 = input.LA(1);

                if ( ((LA1_0>=12 && LA1_0<=13)||LA1_0==15) ) {
                    alt1=1;
                }


                switch (alt1) {
            	case 1 :
            	    // InternalCNL.g:79:3: (lv_requirements_0_0= ruleRequirement )
            	    {
            	    // InternalCNL.g:79:3: (lv_requirements_0_0= ruleRequirement )
            	    // InternalCNL.g:80:4: lv_requirements_0_0= ruleRequirement
            	    {

            	    				newCompositeNode(grammarAccess.getModelAccess().getRequirementsRequirementParserRuleCall_0());
            	    			
            	    pushFollow(FOLLOW_3);
            	    lv_requirements_0_0=ruleRequirement();

            	    state._fsp--;


            	    				if (current==null) {
            	    					current = createModelElementForParent(grammarAccess.getModelRule());
            	    				}
            	    				add(
            	    					current,
            	    					"requirements",
            	    					lv_requirements_0_0,
            	    					"org.xtext.example.CNL.Requirement");
            	    				afterParserOrEnumRuleCall();
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    break loop1;
                }
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleModel"


    // $ANTLR start "entryRuleRequirement"
    // InternalCNL.g:100:1: entryRuleRequirement returns [EObject current=null] : iv_ruleRequirement= ruleRequirement EOF ;
    public final EObject entryRuleRequirement() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRequirement = null;


        try {
            // InternalCNL.g:100:52: (iv_ruleRequirement= ruleRequirement EOF )
            // InternalCNL.g:101:2: iv_ruleRequirement= ruleRequirement EOF
            {
             newCompositeNode(grammarAccess.getRequirementRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRequirement=ruleRequirement();

            state._fsp--;

             current =iv_ruleRequirement; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRequirement"


    // $ANTLR start "ruleRequirement"
    // InternalCNL.g:107:1: ruleRequirement returns [EObject current=null] : ( ( (lv_trigger_0_0= ruleTrig ) ) | ( (lv_invariant_1_0= ruleInv_always ) ) ) ;
    public final EObject ruleRequirement() throws RecognitionException {
        EObject current = null;

        EObject lv_trigger_0_0 = null;

        EObject lv_invariant_1_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:113:2: ( ( ( (lv_trigger_0_0= ruleTrig ) ) | ( (lv_invariant_1_0= ruleInv_always ) ) ) )
            // InternalCNL.g:114:2: ( ( (lv_trigger_0_0= ruleTrig ) ) | ( (lv_invariant_1_0= ruleInv_always ) ) )
            {
            // InternalCNL.g:114:2: ( ( (lv_trigger_0_0= ruleTrig ) ) | ( (lv_invariant_1_0= ruleInv_always ) ) )
            int alt2=2;
            int LA2_0 = input.LA(1);

            if ( (LA2_0==12||LA2_0==15) ) {
                alt2=1;
            }
            else if ( (LA2_0==13) ) {
                alt2=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 2, 0, input);

                throw nvae;
            }
            switch (alt2) {
                case 1 :
                    // InternalCNL.g:115:3: ( (lv_trigger_0_0= ruleTrig ) )
                    {
                    // InternalCNL.g:115:3: ( (lv_trigger_0_0= ruleTrig ) )
                    // InternalCNL.g:116:4: (lv_trigger_0_0= ruleTrig )
                    {
                    // InternalCNL.g:116:4: (lv_trigger_0_0= ruleTrig )
                    // InternalCNL.g:117:5: lv_trigger_0_0= ruleTrig
                    {

                    					newCompositeNode(grammarAccess.getRequirementAccess().getTriggerTrigParserRuleCall_0_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_trigger_0_0=ruleTrig();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRequirementRule());
                    					}
                    					set(
                    						current,
                    						"trigger",
                    						lv_trigger_0_0,
                    						"org.xtext.example.CNL.Trig");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:135:3: ( (lv_invariant_1_0= ruleInv_always ) )
                    {
                    // InternalCNL.g:135:3: ( (lv_invariant_1_0= ruleInv_always ) )
                    // InternalCNL.g:136:4: (lv_invariant_1_0= ruleInv_always )
                    {
                    // InternalCNL.g:136:4: (lv_invariant_1_0= ruleInv_always )
                    // InternalCNL.g:137:5: lv_invariant_1_0= ruleInv_always
                    {

                    					newCompositeNode(grammarAccess.getRequirementAccess().getInvariantInv_alwaysParserRuleCall_1_0());
                    				
                    pushFollow(FOLLOW_2);
                    lv_invariant_1_0=ruleInv_always();

                    state._fsp--;


                    					if (current==null) {
                    						current = createModelElementForParent(grammarAccess.getRequirementRule());
                    					}
                    					set(
                    						current,
                    						"invariant",
                    						lv_invariant_1_0,
                    						"org.xtext.example.CNL.Inv_always");
                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRequirement"


    // $ANTLR start "entryRuleTrig"
    // InternalCNL.g:158:1: entryRuleTrig returns [EObject current=null] : iv_ruleTrig= ruleTrig EOF ;
    public final EObject entryRuleTrig() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleTrig = null;


        try {
            // InternalCNL.g:158:45: (iv_ruleTrig= ruleTrig EOF )
            // InternalCNL.g:159:2: iv_ruleTrig= ruleTrig EOF
            {
             newCompositeNode(grammarAccess.getTrigRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleTrig=ruleTrig();

            state._fsp--;

             current =iv_ruleTrig; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleTrig"


    // $ANTLR start "ruleTrig"
    // InternalCNL.g:165:1: ruleTrig returns [EObject current=null] : ( () ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' ) ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) ) ) ;
    public final EObject ruleTrig() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_6=null;
        EObject lv_trig_3_0 = null;

        EObject lv_invariant_7_0 = null;

        EObject lv_release_reaction_8_0 = null;

        EObject lv_delay_final_9_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:171:2: ( ( () ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' ) ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) ) ) )
            // InternalCNL.g:172:2: ( () ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' ) ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) ) )
            {
            // InternalCNL.g:172:2: ( () ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' ) ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) ) )
            // InternalCNL.g:173:3: () ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' ) ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) )
            {
            // InternalCNL.g:173:3: ()
            // InternalCNL.g:174:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getTrigAccess().getTrigAction_0(),
            					current);
            			

            }

            // InternalCNL.g:180:3: ( (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma ) | otherlv_6= 'Always' )
            int alt3=2;
            int LA3_0 = input.LA(1);

            if ( (LA3_0==12) ) {
                alt3=1;
            }
            else if ( (LA3_0==15) ) {
                alt3=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 3, 0, input);

                throw nvae;
            }
            switch (alt3) {
                case 1 :
                    // InternalCNL.g:181:4: (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma )
                    {
                    // InternalCNL.g:181:4: (otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma )
                    // InternalCNL.g:182:5: otherlv_1= 'After' otherlv_2= '{' ( (lv_trig_3_0= ruleSentence ) ) otherlv_4= '}' ruleComma
                    {
                    otherlv_1=(Token)match(input,12,FOLLOW_4); 

                    					newLeafNode(otherlv_1, grammarAccess.getTrigAccess().getAfterKeyword_1_0_0());
                    				
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_2, grammarAccess.getTrigAccess().getLeftCurlyBracketKeyword_1_0_1());
                    				
                    // InternalCNL.g:190:5: ( (lv_trig_3_0= ruleSentence ) )
                    // InternalCNL.g:191:6: (lv_trig_3_0= ruleSentence )
                    {
                    // InternalCNL.g:191:6: (lv_trig_3_0= ruleSentence )
                    // InternalCNL.g:192:7: lv_trig_3_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getTrigAccess().getTrigSentenceParserRuleCall_1_0_2_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_trig_3_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getTrigRule());
                    							}
                    							set(
                    								current,
                    								"trig",
                    								lv_trig_3_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_4=(Token)match(input,14,FOLLOW_7); 

                    					newLeafNode(otherlv_4, grammarAccess.getTrigAccess().getRightCurlyBracketKeyword_1_0_3());
                    				

                    					newCompositeNode(grammarAccess.getTrigAccess().getCommaParserRuleCall_1_0_4());
                    				
                    pushFollow(FOLLOW_8);
                    ruleComma();

                    state._fsp--;


                    					afterParserOrEnumRuleCall();
                    				

                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:222:4: otherlv_6= 'Always'
                    {
                    otherlv_6=(Token)match(input,15,FOLLOW_8); 

                    				newLeafNode(otherlv_6, grammarAccess.getTrigAccess().getAlwaysKeyword_1_1());
                    			

                    }
                    break;

            }

            // InternalCNL.g:227:3: ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) )
            int alt4=3;
            alt4 = dfa4.predict(input);
            switch (alt4) {
                case 1 :
                    // InternalCNL.g:228:4: ( (lv_invariant_7_0= ruleInv ) )
                    {
                    // InternalCNL.g:228:4: ( (lv_invariant_7_0= ruleInv ) )
                    // InternalCNL.g:229:5: (lv_invariant_7_0= ruleInv )
                    {
                    // InternalCNL.g:229:5: (lv_invariant_7_0= ruleInv )
                    // InternalCNL.g:230:6: lv_invariant_7_0= ruleInv
                    {

                    						newCompositeNode(grammarAccess.getTrigAccess().getInvariantInvParserRuleCall_2_0_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_invariant_7_0=ruleInv();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTrigRule());
                    						}
                    						set(
                    							current,
                    							"invariant",
                    							lv_invariant_7_0,
                    							"org.xtext.example.CNL.Inv");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:248:4: ( (lv_release_reaction_8_0= ruleRelRea ) )
                    {
                    // InternalCNL.g:248:4: ( (lv_release_reaction_8_0= ruleRelRea ) )
                    // InternalCNL.g:249:5: (lv_release_reaction_8_0= ruleRelRea )
                    {
                    // InternalCNL.g:249:5: (lv_release_reaction_8_0= ruleRelRea )
                    // InternalCNL.g:250:6: lv_release_reaction_8_0= ruleRelRea
                    {

                    						newCompositeNode(grammarAccess.getTrigAccess().getRelease_reactionRelReaParserRuleCall_2_1_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_release_reaction_8_0=ruleRelRea();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTrigRule());
                    						}
                    						set(
                    							current,
                    							"release_reaction",
                    							lv_release_reaction_8_0,
                    							"org.xtext.example.CNL.RelRea");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalCNL.g:268:4: ( (lv_delay_final_9_0= ruleDelFin ) )
                    {
                    // InternalCNL.g:268:4: ( (lv_delay_final_9_0= ruleDelFin ) )
                    // InternalCNL.g:269:5: (lv_delay_final_9_0= ruleDelFin )
                    {
                    // InternalCNL.g:269:5: (lv_delay_final_9_0= ruleDelFin )
                    // InternalCNL.g:270:6: lv_delay_final_9_0= ruleDelFin
                    {

                    						newCompositeNode(grammarAccess.getTrigAccess().getDelay_finalDelFinParserRuleCall_2_2_0());
                    					
                    pushFollow(FOLLOW_2);
                    lv_delay_final_9_0=ruleDelFin();

                    state._fsp--;


                    						if (current==null) {
                    							current = createModelElementForParent(grammarAccess.getTrigRule());
                    						}
                    						set(
                    							current,
                    							"delay_final",
                    							lv_delay_final_9_0,
                    							"org.xtext.example.CNL.DelFin");
                    						afterParserOrEnumRuleCall();
                    					

                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleTrig"


    // $ANTLR start "entryRuleInv"
    // InternalCNL.g:292:1: entryRuleInv returns [EObject current=null] : iv_ruleInv= ruleInv EOF ;
    public final EObject entryRuleInv() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInv = null;


        try {
            // InternalCNL.g:292:44: (iv_ruleInv= ruleInv EOF )
            // InternalCNL.g:293:2: iv_ruleInv= ruleInv EOF
            {
             newCompositeNode(grammarAccess.getInvRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInv=ruleInv();

            state._fsp--;

             current =iv_ruleInv; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInv"


    // $ANTLR start "ruleInv"
    // InternalCNL.g:299:1: ruleInv returns [EObject current=null] : ( () ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) ) ) ;
    public final EObject ruleInv() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        EObject lv_inv_2_0 = null;

        EObject lv_delay_final_6_0 = null;

        EObject lv_inv_9_0 = null;

        EObject lv_release_reaction_15_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:305:2: ( ( () ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) ) ) )
            // InternalCNL.g:306:2: ( () ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) ) )
            {
            // InternalCNL.g:306:2: ( () ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) ) )
            // InternalCNL.g:307:3: () ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) )
            {
            // InternalCNL.g:307:3: ()
            // InternalCNL.g:308:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInvAccess().getInvAction_0(),
            					current);
            			

            }

            // InternalCNL.g:314:3: ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) )
            int alt6=2;
            alt6 = dfa6.predict(input);
            switch (alt6) {
                case 1 :
                    // InternalCNL.g:315:4: (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? )
                    {
                    // InternalCNL.g:315:4: (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? )
                    // InternalCNL.g:316:5: otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )?
                    {
                    otherlv_1=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_1, grammarAccess.getInvAccess().getLeftCurlyBracketKeyword_1_0_0());
                    				
                    // InternalCNL.g:320:5: ( (lv_inv_2_0= ruleSentence ) )
                    // InternalCNL.g:321:6: (lv_inv_2_0= ruleSentence )
                    {
                    // InternalCNL.g:321:6: (lv_inv_2_0= ruleSentence )
                    // InternalCNL.g:322:7: lv_inv_2_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getInvAccess().getInvSentenceParserRuleCall_1_0_1_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_inv_2_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getInvRule());
                    							}
                    							set(
                    								current,
                    								"inv",
                    								lv_inv_2_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_3=(Token)match(input,14,FOLLOW_9); 

                    					newLeafNode(otherlv_3, grammarAccess.getInvAccess().getRightCurlyBracketKeyword_1_0_2());
                    				
                    // InternalCNL.g:343:5: ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )?
                    int alt5=2;
                    int LA5_0 = input.LA(1);

                    if ( (LA5_0==33) ) {
                        alt5=1;
                    }
                    switch (alt5) {
                        case 1 :
                            // InternalCNL.g:344:6: ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}'
                            {

                            						newCompositeNode(grammarAccess.getInvAccess().getCommaParserRuleCall_1_0_3_0());
                            					
                            pushFollow(FOLLOW_4);
                            ruleComma();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            otherlv_5=(Token)match(input,13,FOLLOW_8); 

                            						newLeafNode(otherlv_5, grammarAccess.getInvAccess().getLeftCurlyBracketKeyword_1_0_3_1());
                            					
                            // InternalCNL.g:355:6: ( (lv_delay_final_6_0= ruleDelFin ) )
                            // InternalCNL.g:356:7: (lv_delay_final_6_0= ruleDelFin )
                            {
                            // InternalCNL.g:356:7: (lv_delay_final_6_0= ruleDelFin )
                            // InternalCNL.g:357:8: lv_delay_final_6_0= ruleDelFin
                            {

                            								newCompositeNode(grammarAccess.getInvAccess().getDelay_finalDelFinParserRuleCall_1_0_3_2_0());
                            							
                            pushFollow(FOLLOW_6);
                            lv_delay_final_6_0=ruleDelFin();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getInvRule());
                            								}
                            								set(
                            									current,
                            									"delay_final",
                            									lv_delay_final_6_0,
                            									"org.xtext.example.CNL.DelFin");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }

                            otherlv_7=(Token)match(input,14,FOLLOW_2); 

                            						newLeafNode(otherlv_7, grammarAccess.getInvAccess().getRightCurlyBracketKeyword_1_0_3_3());
                            					

                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:381:4: (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) )
                    {
                    // InternalCNL.g:381:4: (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) )
                    // InternalCNL.g:382:5: otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) )
                    {
                    otherlv_8=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_8, grammarAccess.getInvAccess().getLeftCurlyBracketKeyword_1_1_0());
                    				
                    // InternalCNL.g:386:5: ( (lv_inv_9_0= ruleSentence ) )
                    // InternalCNL.g:387:6: (lv_inv_9_0= ruleSentence )
                    {
                    // InternalCNL.g:387:6: (lv_inv_9_0= ruleSentence )
                    // InternalCNL.g:388:7: lv_inv_9_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getInvAccess().getInvSentenceParserRuleCall_1_1_1_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_inv_9_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getInvRule());
                    							}
                    							set(
                    								current,
                    								"inv",
                    								lv_inv_9_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_10=(Token)match(input,14,FOLLOW_10); 

                    					newLeafNode(otherlv_10, grammarAccess.getInvAccess().getRightCurlyBracketKeyword_1_1_2());
                    				
                    otherlv_11=(Token)match(input,16,FOLLOW_11); 

                    					newLeafNode(otherlv_11, grammarAccess.getInvAccess().getShouldKeyword_1_1_3());
                    				
                    otherlv_12=(Token)match(input,17,FOLLOW_12); 

                    					newLeafNode(otherlv_12, grammarAccess.getInvAccess().getRemainKeyword_1_1_4());
                    				
                    otherlv_13=(Token)match(input,18,FOLLOW_13); 

                    					newLeafNode(otherlv_13, grammarAccess.getInvAccess().getValidKeyword_1_1_5());
                    				
                    otherlv_14=(Token)match(input,19,FOLLOW_14); 

                    					newLeafNode(otherlv_14, grammarAccess.getInvAccess().getUntilKeyword_1_1_6());
                    				
                    // InternalCNL.g:425:5: ( (lv_release_reaction_15_0= ruleRelRea ) )
                    // InternalCNL.g:426:6: (lv_release_reaction_15_0= ruleRelRea )
                    {
                    // InternalCNL.g:426:6: (lv_release_reaction_15_0= ruleRelRea )
                    // InternalCNL.g:427:7: lv_release_reaction_15_0= ruleRelRea
                    {

                    							newCompositeNode(grammarAccess.getInvAccess().getRelease_reactionRelReaParserRuleCall_1_1_7_0());
                    						
                    pushFollow(FOLLOW_2);
                    lv_release_reaction_15_0=ruleRelRea();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getInvRule());
                    							}
                    							set(
                    								current,
                    								"release_reaction",
                    								lv_release_reaction_15_0,
                    								"org.xtext.example.CNL.RelRea");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }


                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInv"


    // $ANTLR start "entryRuleInv_always"
    // InternalCNL.g:450:1: entryRuleInv_always returns [EObject current=null] : iv_ruleInv_always= ruleInv_always EOF ;
    public final EObject entryRuleInv_always() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleInv_always = null;


        try {
            // InternalCNL.g:450:51: (iv_ruleInv_always= ruleInv_always EOF )
            // InternalCNL.g:451:2: iv_ruleInv_always= ruleInv_always EOF
            {
             newCompositeNode(grammarAccess.getInv_alwaysRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleInv_always=ruleInv_always();

            state._fsp--;

             current =iv_ruleInv_always; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleInv_always"


    // $ANTLR start "ruleInv_always"
    // InternalCNL.g:457:1: ruleInv_always returns [EObject current=null] : ( () (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) ) ) ;
    public final EObject ruleInv_always() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        EObject lv_inv_2_0 = null;

        EObject lv_release_reaction_9_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:463:2: ( ( () (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) ) ) )
            // InternalCNL.g:464:2: ( () (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) ) )
            {
            // InternalCNL.g:464:2: ( () (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) ) )
            // InternalCNL.g:465:3: () (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) )
            {
            // InternalCNL.g:465:3: ()
            // InternalCNL.g:466:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getInv_alwaysAccess().getInv_alwaysAction_0(),
            					current);
            			

            }

            // InternalCNL.g:472:3: (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) ) )
            // InternalCNL.g:473:4: otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' otherlv_4= 'should' otherlv_5= 'always' otherlv_6= 'remain' otherlv_7= 'valid' otherlv_8= 'until' ( (lv_release_reaction_9_0= ruleRelRea ) )
            {
            otherlv_1=(Token)match(input,13,FOLLOW_5); 

            				newLeafNode(otherlv_1, grammarAccess.getInv_alwaysAccess().getLeftCurlyBracketKeyword_1_0());
            			
            // InternalCNL.g:477:4: ( (lv_inv_2_0= ruleSentence ) )
            // InternalCNL.g:478:5: (lv_inv_2_0= ruleSentence )
            {
            // InternalCNL.g:478:5: (lv_inv_2_0= ruleSentence )
            // InternalCNL.g:479:6: lv_inv_2_0= ruleSentence
            {

            						newCompositeNode(grammarAccess.getInv_alwaysAccess().getInvSentenceParserRuleCall_1_1_0());
            					
            pushFollow(FOLLOW_6);
            lv_inv_2_0=ruleSentence();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getInv_alwaysRule());
            						}
            						set(
            							current,
            							"inv",
            							lv_inv_2_0,
            							"org.xtext.example.CNL.Sentence");
            						afterParserOrEnumRuleCall();
            					

            }


            }

            otherlv_3=(Token)match(input,14,FOLLOW_10); 

            				newLeafNode(otherlv_3, grammarAccess.getInv_alwaysAccess().getRightCurlyBracketKeyword_1_2());
            			
            otherlv_4=(Token)match(input,16,FOLLOW_15); 

            				newLeafNode(otherlv_4, grammarAccess.getInv_alwaysAccess().getShouldKeyword_1_3());
            			
            otherlv_5=(Token)match(input,20,FOLLOW_11); 

            				newLeafNode(otherlv_5, grammarAccess.getInv_alwaysAccess().getAlwaysKeyword_1_4());
            			
            otherlv_6=(Token)match(input,17,FOLLOW_12); 

            				newLeafNode(otherlv_6, grammarAccess.getInv_alwaysAccess().getRemainKeyword_1_5());
            			
            otherlv_7=(Token)match(input,18,FOLLOW_13); 

            				newLeafNode(otherlv_7, grammarAccess.getInv_alwaysAccess().getValidKeyword_1_6());
            			
            otherlv_8=(Token)match(input,19,FOLLOW_14); 

            				newLeafNode(otherlv_8, grammarAccess.getInv_alwaysAccess().getUntilKeyword_1_7());
            			
            // InternalCNL.g:520:4: ( (lv_release_reaction_9_0= ruleRelRea ) )
            // InternalCNL.g:521:5: (lv_release_reaction_9_0= ruleRelRea )
            {
            // InternalCNL.g:521:5: (lv_release_reaction_9_0= ruleRelRea )
            // InternalCNL.g:522:6: lv_release_reaction_9_0= ruleRelRea
            {

            						newCompositeNode(grammarAccess.getInv_alwaysAccess().getRelease_reactionRelReaParserRuleCall_1_8_0());
            					
            pushFollow(FOLLOW_2);
            lv_release_reaction_9_0=ruleRelRea();

            state._fsp--;


            						if (current==null) {
            							current = createModelElementForParent(grammarAccess.getInv_alwaysRule());
            						}
            						set(
            							current,
            							"release_reaction",
            							lv_release_reaction_9_0,
            							"org.xtext.example.CNL.RelRea");
            						afterParserOrEnumRuleCall();
            					

            }


            }


            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleInv_always"


    // $ANTLR start "entryRuleRelRea"
    // InternalCNL.g:544:1: entryRuleRelRea returns [EObject current=null] : iv_ruleRelRea= ruleRelRea EOF ;
    public final EObject entryRuleRelRea() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleRelRea = null;


        try {
            // InternalCNL.g:544:47: (iv_ruleRelRea= ruleRelRea EOF )
            // InternalCNL.g:545:2: iv_ruleRelRea= ruleRelRea EOF
            {
             newCompositeNode(grammarAccess.getRelReaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleRelRea=ruleRelRea();

            state._fsp--;

             current =iv_ruleRelRea; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleRelRea"


    // $ANTLR start "ruleRelRea"
    // InternalCNL.g:551:1: ruleRelRea returns [EObject current=null] : ( ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) ) | ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) ) ) ;
    public final EObject ruleRelRea() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_6=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_10=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_18=null;
        Token otherlv_19=null;
        Token otherlv_20=null;
        Token otherlv_22=null;
        Token otherlv_26=null;
        Token otherlv_27=null;
        Token otherlv_28=null;
        Token otherlv_29=null;
        Token otherlv_31=null;
        EObject lv_rel_3_0 = null;

        EObject lv_rea_9_0 = null;

        EObject lv_delay_final_12_0 = null;

        EObject lv_rel_15_0 = null;

        EObject lv_rea_21_0 = null;

        EObject lv_delay_final_24_0 = null;

        EObject lv_rea_30_0 = null;

        EObject lv_delay_final_33_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:557:2: ( ( ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) ) | ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) ) ) )
            // InternalCNL.g:558:2: ( ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) ) | ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) ) )
            {
            // InternalCNL.g:558:2: ( ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) ) | ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) ) | ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) ) )
            int alt10=4;
            switch ( input.LA(1) ) {
            case 21:
                {
                alt10=1;
                }
                break;
            case 13:
                {
                alt10=2;
                }
                break;
            case 23:
                {
                alt10=3;
                }
                break;
            case 25:
                {
                alt10=4;
                }
                break;
            default:
                NoViableAltException nvae =
                    new NoViableAltException("", 10, 0, input);

                throw nvae;
            }

            switch (alt10) {
                case 1 :
                    // InternalCNL.g:559:3: ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) )
                    {
                    // InternalCNL.g:559:3: ( () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? ) )
                    // InternalCNL.g:560:4: () (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? )
                    {
                    // InternalCNL.g:560:4: ()
                    // InternalCNL.g:561:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getRelReaAccess().getRelReaAction_0_0(),
                    						current);
                    				

                    }

                    // InternalCNL.g:567:4: (otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )? )
                    // InternalCNL.g:568:5: otherlv_1= 'either' otherlv_2= '{' ( (lv_rel_3_0= ruleSentence ) ) otherlv_4= '}' otherlv_5= 'or' otherlv_6= 'reaction' otherlv_7= 'is' otherlv_8= '{' ( (lv_rea_9_0= ruleSentence ) ) otherlv_10= '}' ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )?
                    {
                    otherlv_1=(Token)match(input,21,FOLLOW_4); 

                    					newLeafNode(otherlv_1, grammarAccess.getRelReaAccess().getEitherKeyword_0_1_0());
                    				
                    otherlv_2=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_2, grammarAccess.getRelReaAccess().getLeftCurlyBracketKeyword_0_1_1());
                    				
                    // InternalCNL.g:576:5: ( (lv_rel_3_0= ruleSentence ) )
                    // InternalCNL.g:577:6: (lv_rel_3_0= ruleSentence )
                    {
                    // InternalCNL.g:577:6: (lv_rel_3_0= ruleSentence )
                    // InternalCNL.g:578:7: lv_rel_3_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getRelReaAccess().getRelSentenceParserRuleCall_0_1_2_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_rel_3_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRelReaRule());
                    							}
                    							set(
                    								current,
                    								"rel",
                    								lv_rel_3_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_4=(Token)match(input,14,FOLLOW_16); 

                    					newLeafNode(otherlv_4, grammarAccess.getRelReaAccess().getRightCurlyBracketKeyword_0_1_3());
                    				
                    otherlv_5=(Token)match(input,22,FOLLOW_17); 

                    					newLeafNode(otherlv_5, grammarAccess.getRelReaAccess().getOrKeyword_0_1_4());
                    				
                    otherlv_6=(Token)match(input,23,FOLLOW_18); 

                    					newLeafNode(otherlv_6, grammarAccess.getRelReaAccess().getReactionKeyword_0_1_5());
                    				
                    otherlv_7=(Token)match(input,24,FOLLOW_4); 

                    					newLeafNode(otherlv_7, grammarAccess.getRelReaAccess().getIsKeyword_0_1_6());
                    				
                    otherlv_8=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_8, grammarAccess.getRelReaAccess().getLeftCurlyBracketKeyword_0_1_7());
                    				
                    // InternalCNL.g:615:5: ( (lv_rea_9_0= ruleSentence ) )
                    // InternalCNL.g:616:6: (lv_rea_9_0= ruleSentence )
                    {
                    // InternalCNL.g:616:6: (lv_rea_9_0= ruleSentence )
                    // InternalCNL.g:617:7: lv_rea_9_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getRelReaAccess().getReaSentenceParserRuleCall_0_1_8_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_rea_9_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRelReaRule());
                    							}
                    							set(
                    								current,
                    								"rea",
                    								lv_rea_9_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_10=(Token)match(input,14,FOLLOW_9); 

                    					newLeafNode(otherlv_10, grammarAccess.getRelReaAccess().getRightCurlyBracketKeyword_0_1_9());
                    				
                    // InternalCNL.g:638:5: ( ruleComma ( (lv_delay_final_12_0= ruleDelFin ) ) )?
                    int alt7=2;
                    int LA7_0 = input.LA(1);

                    if ( (LA7_0==33) ) {
                        alt7=1;
                    }
                    switch (alt7) {
                        case 1 :
                            // InternalCNL.g:639:6: ruleComma ( (lv_delay_final_12_0= ruleDelFin ) )
                            {

                            						newCompositeNode(grammarAccess.getRelReaAccess().getCommaParserRuleCall_0_1_10_0());
                            					
                            pushFollow(FOLLOW_8);
                            ruleComma();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            // InternalCNL.g:646:6: ( (lv_delay_final_12_0= ruleDelFin ) )
                            // InternalCNL.g:647:7: (lv_delay_final_12_0= ruleDelFin )
                            {
                            // InternalCNL.g:647:7: (lv_delay_final_12_0= ruleDelFin )
                            // InternalCNL.g:648:8: lv_delay_final_12_0= ruleDelFin
                            {

                            								newCompositeNode(grammarAccess.getRelReaAccess().getDelay_finalDelFinParserRuleCall_0_1_10_1_0());
                            							
                            pushFollow(FOLLOW_2);
                            lv_delay_final_12_0=ruleDelFin();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getRelReaRule());
                            								}
                            								set(
                            									current,
                            									"delay_final",
                            									lv_delay_final_12_0,
                            									"org.xtext.example.CNL.DelFin");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }


                            }
                            break;

                    }


                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:669:3: ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) )
                    {
                    // InternalCNL.g:669:3: ( () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' ) )
                    // InternalCNL.g:670:4: () (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' )
                    {
                    // InternalCNL.g:670:4: ()
                    // InternalCNL.g:671:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getRelReaAccess().getRelAction_1_0(),
                    						current);
                    				

                    }

                    // InternalCNL.g:677:4: (otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}' )
                    // InternalCNL.g:678:5: otherlv_14= '{' ( (lv_rel_15_0= ruleSentence ) ) otherlv_16= '}'
                    {
                    otherlv_14=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_14, grammarAccess.getRelReaAccess().getLeftCurlyBracketKeyword_1_1_0());
                    				
                    // InternalCNL.g:682:5: ( (lv_rel_15_0= ruleSentence ) )
                    // InternalCNL.g:683:6: (lv_rel_15_0= ruleSentence )
                    {
                    // InternalCNL.g:683:6: (lv_rel_15_0= ruleSentence )
                    // InternalCNL.g:684:7: lv_rel_15_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getRelReaAccess().getRelSentenceParserRuleCall_1_1_1_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_rel_15_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRelReaRule());
                    							}
                    							set(
                    								current,
                    								"rel",
                    								lv_rel_15_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_16=(Token)match(input,14,FOLLOW_2); 

                    					newLeafNode(otherlv_16, grammarAccess.getRelReaAccess().getRightCurlyBracketKeyword_1_1_2());
                    				

                    }


                    }


                    }
                    break;
                case 3 :
                    // InternalCNL.g:708:3: ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) )
                    {
                    // InternalCNL.g:708:3: ( () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? ) )
                    // InternalCNL.g:709:4: () (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? )
                    {
                    // InternalCNL.g:709:4: ()
                    // InternalCNL.g:710:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getRelReaAccess().getReaAction_2_0(),
                    						current);
                    				

                    }

                    // InternalCNL.g:716:4: (otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )? )
                    // InternalCNL.g:717:5: otherlv_18= 'reaction' otherlv_19= 'is' otherlv_20= '{' ( (lv_rea_21_0= ruleSentence ) ) otherlv_22= '}' ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )?
                    {
                    otherlv_18=(Token)match(input,23,FOLLOW_18); 

                    					newLeafNode(otherlv_18, grammarAccess.getRelReaAccess().getReactionKeyword_2_1_0());
                    				
                    otherlv_19=(Token)match(input,24,FOLLOW_4); 

                    					newLeafNode(otherlv_19, grammarAccess.getRelReaAccess().getIsKeyword_2_1_1());
                    				
                    otherlv_20=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_20, grammarAccess.getRelReaAccess().getLeftCurlyBracketKeyword_2_1_2());
                    				
                    // InternalCNL.g:729:5: ( (lv_rea_21_0= ruleSentence ) )
                    // InternalCNL.g:730:6: (lv_rea_21_0= ruleSentence )
                    {
                    // InternalCNL.g:730:6: (lv_rea_21_0= ruleSentence )
                    // InternalCNL.g:731:7: lv_rea_21_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getRelReaAccess().getReaSentenceParserRuleCall_2_1_3_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_rea_21_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRelReaRule());
                    							}
                    							set(
                    								current,
                    								"rea",
                    								lv_rea_21_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_22=(Token)match(input,14,FOLLOW_9); 

                    					newLeafNode(otherlv_22, grammarAccess.getRelReaAccess().getRightCurlyBracketKeyword_2_1_4());
                    				
                    // InternalCNL.g:752:5: ( ruleComma ( (lv_delay_final_24_0= ruleDelFin ) ) )?
                    int alt8=2;
                    int LA8_0 = input.LA(1);

                    if ( (LA8_0==33) ) {
                        alt8=1;
                    }
                    switch (alt8) {
                        case 1 :
                            // InternalCNL.g:753:6: ruleComma ( (lv_delay_final_24_0= ruleDelFin ) )
                            {

                            						newCompositeNode(grammarAccess.getRelReaAccess().getCommaParserRuleCall_2_1_5_0());
                            					
                            pushFollow(FOLLOW_8);
                            ruleComma();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            // InternalCNL.g:760:6: ( (lv_delay_final_24_0= ruleDelFin ) )
                            // InternalCNL.g:761:7: (lv_delay_final_24_0= ruleDelFin )
                            {
                            // InternalCNL.g:761:7: (lv_delay_final_24_0= ruleDelFin )
                            // InternalCNL.g:762:8: lv_delay_final_24_0= ruleDelFin
                            {

                            								newCompositeNode(grammarAccess.getRelReaAccess().getDelay_finalDelFinParserRuleCall_2_1_5_1_0());
                            							
                            pushFollow(FOLLOW_2);
                            lv_delay_final_24_0=ruleDelFin();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getRelReaRule());
                            								}
                            								set(
                            									current,
                            									"delay_final",
                            									lv_delay_final_24_0,
                            									"org.xtext.example.CNL.DelFin");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }


                            }
                            break;

                    }


                    }


                    }


                    }
                    break;
                case 4 :
                    // InternalCNL.g:783:3: ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) )
                    {
                    // InternalCNL.g:783:3: ( () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? ) )
                    // InternalCNL.g:784:4: () (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? )
                    {
                    // InternalCNL.g:784:4: ()
                    // InternalCNL.g:785:5: 
                    {

                    					current = forceCreateModelElement(
                    						grammarAccess.getRelReaAccess().getReaAction_3_0(),
                    						current);
                    				

                    }

                    // InternalCNL.g:791:4: (otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )? )
                    // InternalCNL.g:792:5: otherlv_26= 'Reaction' otherlv_27= 'is' otherlv_28= 'always' otherlv_29= '{' ( (lv_rea_30_0= ruleSentence ) ) otherlv_31= '}' ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )?
                    {
                    otherlv_26=(Token)match(input,25,FOLLOW_18); 

                    					newLeafNode(otherlv_26, grammarAccess.getRelReaAccess().getReactionKeyword_3_1_0());
                    				
                    otherlv_27=(Token)match(input,24,FOLLOW_15); 

                    					newLeafNode(otherlv_27, grammarAccess.getRelReaAccess().getIsKeyword_3_1_1());
                    				
                    otherlv_28=(Token)match(input,20,FOLLOW_4); 

                    					newLeafNode(otherlv_28, grammarAccess.getRelReaAccess().getAlwaysKeyword_3_1_2());
                    				
                    otherlv_29=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_29, grammarAccess.getRelReaAccess().getLeftCurlyBracketKeyword_3_1_3());
                    				
                    // InternalCNL.g:808:5: ( (lv_rea_30_0= ruleSentence ) )
                    // InternalCNL.g:809:6: (lv_rea_30_0= ruleSentence )
                    {
                    // InternalCNL.g:809:6: (lv_rea_30_0= ruleSentence )
                    // InternalCNL.g:810:7: lv_rea_30_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getRelReaAccess().getReaSentenceParserRuleCall_3_1_4_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_rea_30_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getRelReaRule());
                    							}
                    							set(
                    								current,
                    								"rea",
                    								lv_rea_30_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_31=(Token)match(input,14,FOLLOW_9); 

                    					newLeafNode(otherlv_31, grammarAccess.getRelReaAccess().getRightCurlyBracketKeyword_3_1_5());
                    				
                    // InternalCNL.g:831:5: ( ruleComma ( (lv_delay_final_33_0= ruleDelFin ) ) )?
                    int alt9=2;
                    int LA9_0 = input.LA(1);

                    if ( (LA9_0==33) ) {
                        alt9=1;
                    }
                    switch (alt9) {
                        case 1 :
                            // InternalCNL.g:832:6: ruleComma ( (lv_delay_final_33_0= ruleDelFin ) )
                            {

                            						newCompositeNode(grammarAccess.getRelReaAccess().getCommaParserRuleCall_3_1_6_0());
                            					
                            pushFollow(FOLLOW_8);
                            ruleComma();

                            state._fsp--;


                            						afterParserOrEnumRuleCall();
                            					
                            // InternalCNL.g:839:6: ( (lv_delay_final_33_0= ruleDelFin ) )
                            // InternalCNL.g:840:7: (lv_delay_final_33_0= ruleDelFin )
                            {
                            // InternalCNL.g:840:7: (lv_delay_final_33_0= ruleDelFin )
                            // InternalCNL.g:841:8: lv_delay_final_33_0= ruleDelFin
                            {

                            								newCompositeNode(grammarAccess.getRelReaAccess().getDelay_finalDelFinParserRuleCall_3_1_6_1_0());
                            							
                            pushFollow(FOLLOW_2);
                            lv_delay_final_33_0=ruleDelFin();

                            state._fsp--;


                            								if (current==null) {
                            									current = createModelElementForParent(grammarAccess.getRelReaRule());
                            								}
                            								set(
                            									current,
                            									"delay_final",
                            									lv_delay_final_33_0,
                            									"org.xtext.example.CNL.DelFin");
                            								afterParserOrEnumRuleCall();
                            							

                            }


                            }


                            }
                            break;

                    }


                    }


                    }


                    }
                    break;

            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleRelRea"


    // $ANTLR start "entryRuleDelFin"
    // InternalCNL.g:865:1: entryRuleDelFin returns [EObject current=null] : iv_ruleDelFin= ruleDelFin EOF ;
    public final EObject entryRuleDelFin() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleDelFin = null;


        try {
            // InternalCNL.g:865:47: (iv_ruleDelFin= ruleDelFin EOF )
            // InternalCNL.g:866:2: iv_ruleDelFin= ruleDelFin EOF
            {
             newCompositeNode(grammarAccess.getDelFinRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleDelFin=ruleDelFin();

            state._fsp--;

             current =iv_ruleDelFin; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleDelFin"


    // $ANTLR start "ruleDelFin"
    // InternalCNL.g:872:1: ruleDelFin returns [EObject current=null] : ( () ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) ) ) ;
    public final EObject ruleDelFin() throws RecognitionException {
        EObject current = null;

        Token otherlv_1=null;
        Token otherlv_2=null;
        Token otherlv_3=null;
        Token otherlv_4=null;
        Token otherlv_5=null;
        Token otherlv_7=null;
        Token otherlv_8=null;
        Token otherlv_9=null;
        Token otherlv_11=null;
        Token otherlv_12=null;
        Token otherlv_13=null;
        Token otherlv_14=null;
        Token otherlv_16=null;
        Token otherlv_17=null;
        Token otherlv_19=null;
        EObject lv_del_6_0 = null;

        EObject lv_fin_10_0 = null;

        EObject lv_fin_15_0 = null;

        EObject lv_fin_18_0 = null;



        	enterRule();

        try {
            // InternalCNL.g:878:2: ( ( () ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) ) ) )
            // InternalCNL.g:879:2: ( () ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) ) )
            {
            // InternalCNL.g:879:2: ( () ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) ) )
            // InternalCNL.g:880:3: () ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) )
            {
            // InternalCNL.g:880:3: ()
            // InternalCNL.g:881:4: 
            {

            				current = forceCreateModelElement(
            					grammarAccess.getDelFinAccess().getDelFinAction_0(),
            					current);
            			

            }

            // InternalCNL.g:887:3: ( ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) ) | (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' ) )
            int alt14=2;
            int LA14_0 = input.LA(1);

            if ( (LA14_0==26) ) {
                alt14=1;
            }
            else if ( (LA14_0==13) ) {
                alt14=2;
            }
            else {
                NoViableAltException nvae =
                    new NoViableAltException("", 14, 0, input);

                throw nvae;
            }
            switch (alt14) {
                case 1 :
                    // InternalCNL.g:888:4: ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) )
                    {
                    // InternalCNL.g:888:4: ( (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) ) )
                    // InternalCNL.g:889:5: (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' ) ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) )
                    {
                    // InternalCNL.g:889:5: (otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur' )
                    // InternalCNL.g:890:6: otherlv_1= 'which' otherlv_2= 'must' otherlv_3= 'occur'
                    {
                    otherlv_1=(Token)match(input,26,FOLLOW_19); 

                    						newLeafNode(otherlv_1, grammarAccess.getDelFinAccess().getWhichKeyword_1_0_0_0());
                    					
                    otherlv_2=(Token)match(input,27,FOLLOW_20); 

                    						newLeafNode(otherlv_2, grammarAccess.getDelFinAccess().getMustKeyword_1_0_0_1());
                    					
                    otherlv_3=(Token)match(input,28,FOLLOW_21); 

                    						newLeafNode(otherlv_3, grammarAccess.getDelFinAccess().getOccurKeyword_1_0_0_2());
                    					

                    }

                    // InternalCNL.g:903:5: ( (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? ) | ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' ) )
                    int alt13=2;
                    int LA13_0 = input.LA(1);

                    if ( (LA13_0==29) ) {
                        alt13=1;
                    }
                    else if ( ((LA13_0>=31 && LA13_0<=32)) ) {
                        alt13=2;
                    }
                    else {
                        NoViableAltException nvae =
                            new NoViableAltException("", 13, 0, input);

                        throw nvae;
                    }
                    switch (alt13) {
                        case 1 :
                            // InternalCNL.g:904:6: (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? )
                            {
                            // InternalCNL.g:904:6: (otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )? )
                            // InternalCNL.g:905:7: otherlv_4= 'within' otherlv_5= '{' ( (lv_del_6_0= ruleSentence ) ) otherlv_7= '}' (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )?
                            {
                            otherlv_4=(Token)match(input,29,FOLLOW_4); 

                            							newLeafNode(otherlv_4, grammarAccess.getDelFinAccess().getWithinKeyword_1_0_1_0_0());
                            						
                            otherlv_5=(Token)match(input,13,FOLLOW_5); 

                            							newLeafNode(otherlv_5, grammarAccess.getDelFinAccess().getLeftCurlyBracketKeyword_1_0_1_0_1());
                            						
                            // InternalCNL.g:913:7: ( (lv_del_6_0= ruleSentence ) )
                            // InternalCNL.g:914:8: (lv_del_6_0= ruleSentence )
                            {
                            // InternalCNL.g:914:8: (lv_del_6_0= ruleSentence )
                            // InternalCNL.g:915:9: lv_del_6_0= ruleSentence
                            {

                            									newCompositeNode(grammarAccess.getDelFinAccess().getDelSentenceParserRuleCall_1_0_1_0_2_0());
                            								
                            pushFollow(FOLLOW_6);
                            lv_del_6_0=ruleSentence();

                            state._fsp--;


                            									if (current==null) {
                            										current = createModelElementForParent(grammarAccess.getDelFinRule());
                            									}
                            									set(
                            										current,
                            										"del",
                            										lv_del_6_0,
                            										"org.xtext.example.CNL.Sentence");
                            									afterParserOrEnumRuleCall();
                            								

                            }


                            }

                            otherlv_7=(Token)match(input,14,FOLLOW_22); 

                            							newLeafNode(otherlv_7, grammarAccess.getDelFinAccess().getRightCurlyBracketKeyword_1_0_1_0_3());
                            						
                            // InternalCNL.g:936:7: (otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}' )?
                            int alt11=2;
                            int LA11_0 = input.LA(1);

                            if ( (LA11_0==30) ) {
                                alt11=1;
                            }
                            switch (alt11) {
                                case 1 :
                                    // InternalCNL.g:937:8: otherlv_8= 'from' otherlv_9= '{' ( (lv_fin_10_0= ruleSentence ) ) otherlv_11= '}'
                                    {
                                    otherlv_8=(Token)match(input,30,FOLLOW_4); 

                                    								newLeafNode(otherlv_8, grammarAccess.getDelFinAccess().getFromKeyword_1_0_1_0_4_0());
                                    							
                                    otherlv_9=(Token)match(input,13,FOLLOW_5); 

                                    								newLeafNode(otherlv_9, grammarAccess.getDelFinAccess().getLeftCurlyBracketKeyword_1_0_1_0_4_1());
                                    							
                                    // InternalCNL.g:945:8: ( (lv_fin_10_0= ruleSentence ) )
                                    // InternalCNL.g:946:9: (lv_fin_10_0= ruleSentence )
                                    {
                                    // InternalCNL.g:946:9: (lv_fin_10_0= ruleSentence )
                                    // InternalCNL.g:947:10: lv_fin_10_0= ruleSentence
                                    {

                                    										newCompositeNode(grammarAccess.getDelFinAccess().getFinSentenceParserRuleCall_1_0_1_0_4_2_0());
                                    									
                                    pushFollow(FOLLOW_6);
                                    lv_fin_10_0=ruleSentence();

                                    state._fsp--;


                                    										if (current==null) {
                                    											current = createModelElementForParent(grammarAccess.getDelFinRule());
                                    										}
                                    										set(
                                    											current,
                                    											"fin",
                                    											lv_fin_10_0,
                                    											"org.xtext.example.CNL.Sentence");
                                    										afterParserOrEnumRuleCall();
                                    									

                                    }


                                    }

                                    otherlv_11=(Token)match(input,14,FOLLOW_2); 

                                    								newLeafNode(otherlv_11, grammarAccess.getDelFinAccess().getRightCurlyBracketKeyword_1_0_1_0_4_3());
                                    							

                                    }
                                    break;

                            }


                            }


                            }
                            break;
                        case 2 :
                            // InternalCNL.g:971:6: ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' )
                            {
                            // InternalCNL.g:971:6: ( (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}' )
                            // InternalCNL.g:972:7: (otherlv_12= 'immediately' )? otherlv_13= 'after' otherlv_14= '{' ( (lv_fin_15_0= ruleSentence ) ) otherlv_16= '}'
                            {
                            // InternalCNL.g:972:7: (otherlv_12= 'immediately' )?
                            int alt12=2;
                            int LA12_0 = input.LA(1);

                            if ( (LA12_0==31) ) {
                                alt12=1;
                            }
                            switch (alt12) {
                                case 1 :
                                    // InternalCNL.g:973:8: otherlv_12= 'immediately'
                                    {
                                    otherlv_12=(Token)match(input,31,FOLLOW_23); 

                                    								newLeafNode(otherlv_12, grammarAccess.getDelFinAccess().getImmediatelyKeyword_1_0_1_1_0());
                                    							

                                    }
                                    break;

                            }

                            otherlv_13=(Token)match(input,32,FOLLOW_4); 

                            							newLeafNode(otherlv_13, grammarAccess.getDelFinAccess().getAfterKeyword_1_0_1_1_1());
                            						
                            otherlv_14=(Token)match(input,13,FOLLOW_5); 

                            							newLeafNode(otherlv_14, grammarAccess.getDelFinAccess().getLeftCurlyBracketKeyword_1_0_1_1_2());
                            						
                            // InternalCNL.g:986:7: ( (lv_fin_15_0= ruleSentence ) )
                            // InternalCNL.g:987:8: (lv_fin_15_0= ruleSentence )
                            {
                            // InternalCNL.g:987:8: (lv_fin_15_0= ruleSentence )
                            // InternalCNL.g:988:9: lv_fin_15_0= ruleSentence
                            {

                            									newCompositeNode(grammarAccess.getDelFinAccess().getFinSentenceParserRuleCall_1_0_1_1_3_0());
                            								
                            pushFollow(FOLLOW_6);
                            lv_fin_15_0=ruleSentence();

                            state._fsp--;


                            									if (current==null) {
                            										current = createModelElementForParent(grammarAccess.getDelFinRule());
                            									}
                            									set(
                            										current,
                            										"fin",
                            										lv_fin_15_0,
                            										"org.xtext.example.CNL.Sentence");
                            									afterParserOrEnumRuleCall();
                            								

                            }


                            }

                            otherlv_16=(Token)match(input,14,FOLLOW_2); 

                            							newLeafNode(otherlv_16, grammarAccess.getDelFinAccess().getRightCurlyBracketKeyword_1_0_1_1_4());
                            						

                            }


                            }
                            break;

                    }


                    }


                    }
                    break;
                case 2 :
                    // InternalCNL.g:1013:4: (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' )
                    {
                    // InternalCNL.g:1013:4: (otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}' )
                    // InternalCNL.g:1014:5: otherlv_17= '{' ( (lv_fin_18_0= ruleSentence ) ) otherlv_19= '}'
                    {
                    otherlv_17=(Token)match(input,13,FOLLOW_5); 

                    					newLeafNode(otherlv_17, grammarAccess.getDelFinAccess().getLeftCurlyBracketKeyword_1_1_0());
                    				
                    // InternalCNL.g:1018:5: ( (lv_fin_18_0= ruleSentence ) )
                    // InternalCNL.g:1019:6: (lv_fin_18_0= ruleSentence )
                    {
                    // InternalCNL.g:1019:6: (lv_fin_18_0= ruleSentence )
                    // InternalCNL.g:1020:7: lv_fin_18_0= ruleSentence
                    {

                    							newCompositeNode(grammarAccess.getDelFinAccess().getFinSentenceParserRuleCall_1_1_1_0());
                    						
                    pushFollow(FOLLOW_6);
                    lv_fin_18_0=ruleSentence();

                    state._fsp--;


                    							if (current==null) {
                    								current = createModelElementForParent(grammarAccess.getDelFinRule());
                    							}
                    							set(
                    								current,
                    								"fin",
                    								lv_fin_18_0,
                    								"org.xtext.example.CNL.Sentence");
                    							afterParserOrEnumRuleCall();
                    						

                    }


                    }

                    otherlv_19=(Token)match(input,14,FOLLOW_2); 

                    					newLeafNode(otherlv_19, grammarAccess.getDelFinAccess().getRightCurlyBracketKeyword_1_1_2());
                    				

                    }


                    }
                    break;

            }


            }


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleDelFin"


    // $ANTLR start "entryRuleSentence"
    // InternalCNL.g:1047:1: entryRuleSentence returns [EObject current=null] : iv_ruleSentence= ruleSentence EOF ;
    public final EObject entryRuleSentence() throws RecognitionException {
        EObject current = null;

        EObject iv_ruleSentence = null;


        try {
            // InternalCNL.g:1047:49: (iv_ruleSentence= ruleSentence EOF )
            // InternalCNL.g:1048:2: iv_ruleSentence= ruleSentence EOF
            {
             newCompositeNode(grammarAccess.getSentenceRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleSentence=ruleSentence();

            state._fsp--;

             current =iv_ruleSentence; 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleSentence"


    // $ANTLR start "ruleSentence"
    // InternalCNL.g:1054:1: ruleSentence returns [EObject current=null] : ( (lv_ids_0_0= RULE_WORD ) )+ ;
    public final EObject ruleSentence() throws RecognitionException {
        EObject current = null;

        Token lv_ids_0_0=null;


        	enterRule();

        try {
            // InternalCNL.g:1060:2: ( ( (lv_ids_0_0= RULE_WORD ) )+ )
            // InternalCNL.g:1061:2: ( (lv_ids_0_0= RULE_WORD ) )+
            {
            // InternalCNL.g:1061:2: ( (lv_ids_0_0= RULE_WORD ) )+
            int cnt15=0;
            loop15:
            do {
                int alt15=2;
                int LA15_0 = input.LA(1);

                if ( (LA15_0==RULE_WORD) ) {
                    alt15=1;
                }


                switch (alt15) {
            	case 1 :
            	    // InternalCNL.g:1062:3: (lv_ids_0_0= RULE_WORD )
            	    {
            	    // InternalCNL.g:1062:3: (lv_ids_0_0= RULE_WORD )
            	    // InternalCNL.g:1063:4: lv_ids_0_0= RULE_WORD
            	    {
            	    lv_ids_0_0=(Token)match(input,RULE_WORD,FOLLOW_24); 

            	    				newLeafNode(lv_ids_0_0, grammarAccess.getSentenceAccess().getIdsWORDTerminalRuleCall_0());
            	    			

            	    				if (current==null) {
            	    					current = createModelElement(grammarAccess.getSentenceRule());
            	    				}
            	    				addWithLastConsumed(
            	    					current,
            	    					"ids",
            	    					lv_ids_0_0,
            	    					"org.xtext.example.CNL.WORD");
            	    			

            	    }


            	    }
            	    break;

            	default :
            	    if ( cnt15 >= 1 ) break loop15;
                        EarlyExitException eee =
                            new EarlyExitException(15, input);
                        throw eee;
                }
                cnt15++;
            } while (true);


            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleSentence"


    // $ANTLR start "entryRuleComma"
    // InternalCNL.g:1082:1: entryRuleComma returns [String current=null] : iv_ruleComma= ruleComma EOF ;
    public final String entryRuleComma() throws RecognitionException {
        String current = null;

        AntlrDatatypeRuleToken iv_ruleComma = null;


        try {
            // InternalCNL.g:1082:45: (iv_ruleComma= ruleComma EOF )
            // InternalCNL.g:1083:2: iv_ruleComma= ruleComma EOF
            {
             newCompositeNode(grammarAccess.getCommaRule()); 
            pushFollow(FOLLOW_1);
            iv_ruleComma=ruleComma();

            state._fsp--;

             current =iv_ruleComma.getText(); 
            match(input,EOF,FOLLOW_2); 

            }

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "entryRuleComma"


    // $ANTLR start "ruleComma"
    // InternalCNL.g:1089:1: ruleComma returns [AntlrDatatypeRuleToken current=new AntlrDatatypeRuleToken()] : kw= ',' ;
    public final AntlrDatatypeRuleToken ruleComma() throws RecognitionException {
        AntlrDatatypeRuleToken current = new AntlrDatatypeRuleToken();

        Token kw=null;


        	enterRule();

        try {
            // InternalCNL.g:1095:2: (kw= ',' )
            // InternalCNL.g:1096:2: kw= ','
            {
            kw=(Token)match(input,33,FOLLOW_2); 

            		current.merge(kw);
            		newLeafNode(kw, grammarAccess.getCommaAccess().getCommaKeyword());
            	

            }


            	leaveRule();

        }

            catch (RecognitionException re) {
                recover(input,re);
                appendSkippedTokens();
            }
        finally {
        }
        return current;
    }
    // $ANTLR end "ruleComma"

    // Delegated rules


    protected DFA4 dfa4 = new DFA4(this);
    protected DFA6 dfa6 = new DFA6(this);
    static final String dfa_1s = "\6\uffff";
    static final String dfa_2s = "\1\15\1\4\2\uffff\1\4\1\uffff";
    static final String dfa_3s = "\1\32\1\4\2\uffff\1\16\1\uffff";
    static final String dfa_4s = "\2\uffff\1\2\1\3\1\uffff\1\1";
    static final String dfa_5s = "\6\uffff}>";
    static final String[] dfa_6s = {
            "\1\1\7\uffff\1\2\1\uffff\1\2\1\uffff\1\2\1\3",
            "\1\4",
            "",
            "",
            "\1\4\11\uffff\1\5",
            ""
    };

    static final short[] dfa_1 = DFA.unpackEncodedString(dfa_1s);
    static final char[] dfa_2 = DFA.unpackEncodedStringToUnsignedChars(dfa_2s);
    static final char[] dfa_3 = DFA.unpackEncodedStringToUnsignedChars(dfa_3s);
    static final short[] dfa_4 = DFA.unpackEncodedString(dfa_4s);
    static final short[] dfa_5 = DFA.unpackEncodedString(dfa_5s);
    static final short[][] dfa_6 = unpackEncodedStringArray(dfa_6s);

    class DFA4 extends DFA {

        public DFA4(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 4;
            this.eot = dfa_1;
            this.eof = dfa_1;
            this.min = dfa_2;
            this.max = dfa_3;
            this.accept = dfa_4;
            this.special = dfa_5;
            this.transition = dfa_6;
        }
        public String getDescription() {
            return "227:3: ( ( (lv_invariant_7_0= ruleInv ) ) | ( (lv_release_reaction_8_0= ruleRelRea ) ) | ( (lv_delay_final_9_0= ruleDelFin ) ) )";
        }
    }
    static final String dfa_7s = "\3\uffff\1\4\2\uffff";
    static final String dfa_8s = "\1\15\2\4\1\14\2\uffff";
    static final String dfa_9s = "\1\15\1\4\1\16\1\41\2\uffff";
    static final String dfa_10s = "\4\uffff\1\1\1\2";
    static final String[] dfa_11s = {
            "\1\1",
            "\1\2",
            "\1\2\11\uffff\1\3",
            "\2\4\1\uffff\1\4\1\5\20\uffff\1\4",
            "",
            ""
    };
    static final short[] dfa_7 = DFA.unpackEncodedString(dfa_7s);
    static final char[] dfa_8 = DFA.unpackEncodedStringToUnsignedChars(dfa_8s);
    static final char[] dfa_9 = DFA.unpackEncodedStringToUnsignedChars(dfa_9s);
    static final short[] dfa_10 = DFA.unpackEncodedString(dfa_10s);
    static final short[][] dfa_11 = unpackEncodedStringArray(dfa_11s);

    class DFA6 extends DFA {

        public DFA6(BaseRecognizer recognizer) {
            this.recognizer = recognizer;
            this.decisionNumber = 6;
            this.eot = dfa_1;
            this.eof = dfa_7;
            this.min = dfa_8;
            this.max = dfa_9;
            this.accept = dfa_10;
            this.special = dfa_5;
            this.transition = dfa_11;
        }
        public String getDescription() {
            return "314:3: ( (otherlv_1= '{' ( (lv_inv_2_0= ruleSentence ) ) otherlv_3= '}' ( ruleComma otherlv_5= '{' ( (lv_delay_final_6_0= ruleDelFin ) ) otherlv_7= '}' )? ) | (otherlv_8= '{' ( (lv_inv_9_0= ruleSentence ) ) otherlv_10= '}' otherlv_11= 'should' otherlv_12= 'remain' otherlv_13= 'valid' otherlv_14= 'until' ( (lv_release_reaction_15_0= ruleRelRea ) ) ) )";
        }
    }
 

    public static final BitSet FOLLOW_1 = new BitSet(new long[]{0x0000000000000000L});
    public static final BitSet FOLLOW_2 = new BitSet(new long[]{0x0000000000000002L});
    public static final BitSet FOLLOW_3 = new BitSet(new long[]{0x000000000000B002L});
    public static final BitSet FOLLOW_4 = new BitSet(new long[]{0x0000000000002000L});
    public static final BitSet FOLLOW_5 = new BitSet(new long[]{0x0000000000000010L});
    public static final BitSet FOLLOW_6 = new BitSet(new long[]{0x0000000000004000L});
    public static final BitSet FOLLOW_7 = new BitSet(new long[]{0x0000000200000000L});
    public static final BitSet FOLLOW_8 = new BitSet(new long[]{0x0000000006A02000L});
    public static final BitSet FOLLOW_9 = new BitSet(new long[]{0x0000000200000002L});
    public static final BitSet FOLLOW_10 = new BitSet(new long[]{0x0000000000010000L});
    public static final BitSet FOLLOW_11 = new BitSet(new long[]{0x0000000000020000L});
    public static final BitSet FOLLOW_12 = new BitSet(new long[]{0x0000000000040000L});
    public static final BitSet FOLLOW_13 = new BitSet(new long[]{0x0000000000080000L});
    public static final BitSet FOLLOW_14 = new BitSet(new long[]{0x0000000002A02000L});
    public static final BitSet FOLLOW_15 = new BitSet(new long[]{0x0000000000100000L});
    public static final BitSet FOLLOW_16 = new BitSet(new long[]{0x0000000000400000L});
    public static final BitSet FOLLOW_17 = new BitSet(new long[]{0x0000000000800000L});
    public static final BitSet FOLLOW_18 = new BitSet(new long[]{0x0000000001000000L});
    public static final BitSet FOLLOW_19 = new BitSet(new long[]{0x0000000008000000L});
    public static final BitSet FOLLOW_20 = new BitSet(new long[]{0x0000000010000000L});
    public static final BitSet FOLLOW_21 = new BitSet(new long[]{0x00000001A0000000L});
    public static final BitSet FOLLOW_22 = new BitSet(new long[]{0x0000000040000002L});
    public static final BitSet FOLLOW_23 = new BitSet(new long[]{0x0000000100000000L});
    public static final BitSet FOLLOW_24 = new BitSet(new long[]{0x0000000000000012L});

}